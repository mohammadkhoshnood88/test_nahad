@extends('layouts.admin')

@section('content')
    <div class="page-loader">
        <div class="page-loader__spinner">
            <svg viewbox="25 25 50 50">
                <circle cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10"></circle>
            </svg>
        </div>
    </div>

    <section class="content">
        <div class="content__inner">
            <header class="content__title">
                <div class="actions">
                    <a href="html-table.html" class="actions__item zwicon-cog"></a>
                    <a href="/admin/adm_brand" class="actions__item zwicon-refresh-double"></a>

                    <div class="dropdown actions__item">
                        <i data-toggle="dropdown" class="zwicon-more-h"></i>
                        <div class="dropdown-menu dropdown-menu-right">
                            <a href="/admin/adm_brand" class="dropdown-item">بارگذاری مجدد</a>
                            <a href="/admin/adm_brand" class="dropdown-item">لیست برند ها</a>                            
                        </div>
                    </div>
                </div>
                <h1 class="text-right"> اضافه کردن برند</h1>

                
            </header>

            <div class="card">
                <div class="card-body" style="direction: rtl">
                    <h4 class="card-title text-right">برند جدید خودرو </h4>     
                    
                    {{-- <form action="{{url('/brandstore')}}" method="POST" enctype="multipart/form-data">
                        @csrf
                    </form> --}}

                        <div class="row">

                            <div class="col-md-6">
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">عنوان </span>
                                    </div>
                                    <input type="text" id="brand_subject" name="brand_subject" class="form-control" />
                                </div>
                            </div>
    
                            <div class="col-md-6 text-center">
                                <button type="submit" id="brand_submit" class="btn btn-info btn--icon-text pl-4" style="font-size: 16px"><i class="zwicon-checkmark ml-1" style="font-size: 1.8rem;"></i> ثبت </button>
                            </div>
                        </div> 
                                                   
                </div>
            </div>
        </div>
    </section>
@endsection

@section('scripts')

    <script>

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $(document).ready(function() {
            
            $("#brand_submit").on('click',function(){
                var brand_subject = $("#brand_subject").val();                

                if(brand_subject == "")

                    Swal.fire({
                        icon: 'error',
                        title: 'خطا',
                        text: 'عنوان را وارد کنید',                                
                    });

                $.ajax({
                    url:'/brandstore',
                    data:{"brand_subject":brand_subject},
                    method:'post',
                    success:function(data){
                        Swal.fire({
                            icon: 'success',
                            title: 'تایید',
                            text: 'برند جدید با موفقیت ثبت گردید',
                            timer: 2000,
                            confirmButton: false,
                        }) 
                        
                        location.reload();
                                               
                    },                    
                    error:function(exception){
                        console.log(exception);
                    }                    
                });                
            });
        });

    </script>

@endsection

