@extends('layouts.admin')

@section('content')
    <style>
        .exam-name {
            font-size: 14px;
            font-weight: bold;
            color: #73879C;
            width: 100%;
            text-align: right;
            margin-bottom: 5px;
            margin-right: 5px;
            display: inline-block;
            padding: 6px 12px;
            line-height: 1.42857143;
            vertical-align: middle;
            cursor: pointer;
            background: rgba(0,0,0,0.2);
        }
    </style>

    <section class="content">
        <div class="content__inner">
            <header class="content__title">
                <div class="actions">
                    <a href="html-table.html" class="actions__item zwicon-cog"></a>
                    <a href="/admin/adm_brand" class="actions__item zwicon-refresh-double"></a>

                    <div class="dropdown actions__item">
                        <i data-toggle="dropdown" class="zwicon-more-h"></i>
                        <div class="dropdown-menu dropdown-menu-right">

                        </div>
                    </div>
                </div>
                <h1 class="text-right">تبلیغات لوازم یدکی</h1>


            </header>
            @foreach($errors as $error)
                <span>{{$error}}</span>
            @endforeach
            <div class="card">
                <div class="card-body" style="direction: rtl">
                    <h4 class="card-title text-right">تعریف فروشگاه جدید</h4>

                    <form action="{{route('add_ads_access')}}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="row">

                            <div class="col-md-6">
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">نام فروشگاه </span>
                                    </div>
                                    <input type="text" id="brand_subject" name="name" class="form-control"/>
                                </div>
{{--                                <div class="input-group mb-3">--}}
{{--                                    <div class="input-group-prepend">--}}
{{--                                        <span class="input-group-text">استان </span>--}}
{{--                                    </div>--}}
{{--                                    <select type="text" id="states" name="state_id" class="form-control states w-75">--}}
{{--                                        <option>استان مورد نظر را وارد کنید</option>--}}
{{--                                        @foreach($states as $state)--}}
{{--                                            <option value="{{$state->id}}">{{$state->name}}</option>--}}
{{--                                        @endforeach--}}
{{--                                    </select>--}}
{{--                                </div>--}}
{{--                                <div class="input-group mb-3">--}}
{{--                                    <div class="input-group-prepend">--}}
{{--                                        <span class="input-group-text">شهر </span>--}}
{{--                                    </div>--}}
{{--                                    <select type="text" name="city_id" id="city_id" class="form-control cities">--}}
{{--                                        <option value="">ابتدا استان را انتخاب کنید</option>--}}

{{--                                    </select>--}}
{{--                                </div>--}}
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">آدرس </span>
                                    </div>
                                    <input type="text" id="brand_subject" name="address" class="form-control"/>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">تلفن </span>
                                    </div>
                                    <input type="text" name="tel" class="form-control"/>
                                </div>

                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">تصویر </span>
                                    </div>
                                    <input type="file" name="main_img" class="form-control"/>
                                </div>


                            </div>
                            <div class="text-center mx-auto">
                                <button type="submit" class="btn btn-info btn--icon-text pl-4 mx-auto"
                                        style="font-size: 16px"><i class="zwicon-checkmark ml-1"
                                                                   style="font-size: 1.8rem;"></i> ثبت
                                </button>
                            </div>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <section class="content">

        <div style="height: 320px;padding: 10px;"
             class="col-md-12 col-sm-12 col-xs-12 exam-child">
            <div class="content-exam">
                <div class="table-responsive text-center dir_rtl">
                    <table class="table table-striped">
                    <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">نام</th>
{{--                        <th scope="col">استان-شهر</th>--}}
                        <th scope="col">آدرس</th>
                        <th scope="col">تلفن</th>
                        <th scope="col">تصویر</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($accesses as $access)
                        <tr>
                            <th scope="row">{{$loop->index +1}}</th>
                            <th scope="row">{{$access->name}}</th>
{{--                            <td>{{$access->state()}}-{{$access->city()}}</td>--}}
                            <td>{{$access->address}}</td>
                            <td>{{$access->phone_number}}</td>
                            <td>
                                <img style="height: 100px;width: 100px" src="/advertise/{{$access->main_Img}}">
                            </td>
                        </tr>
                    @endforeach

                    </tbody>
                </table>
                </div>
            </div>
        </div>

    </section>


@endsection

@section('scripts')
    <script type="text/javascript">


        $(document).ready(function () {
            $(".states").select2({});
        });

        $(document).ready(function () {
            $(".cities").select2({});
        });
    </script>

    <script>

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $(document).ready(function () {

            $("#states").on('change', function () {
                var state_id = $("#states").val();

                if (state_id == "")

                    Swal.fire({
                        icon: 'error',
                        title: 'خطا',
                        text: 'عنوان را وارد کنید',
                    });

                var pdata = {"stateId":state_id};
                $.ajax({
                    url:'/Posts/getCity',
                    data:pdata,
                    method:'post',
                    success:function(x){
                        $("#city_id").html(x);
                    },
                    error:function(exception){
                        console.log(exception);
                    }

                });
            });
        });

    </script>

@endsection
