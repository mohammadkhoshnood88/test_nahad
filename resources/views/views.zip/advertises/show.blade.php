@extends('layout.Main')

@section('style')

    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.6.0/dist/leaflet.css"
          integrity="sha512-xwE/Az9zrjBIphAcBb3F6JVqxf46+CDLwfLMHloNu6KEQCAWi6HcDUbeOfBIptF7tcCzusKFjFw2yuvEpDL9wQ=="
          crossorigin=""/>

    <style>
        .leaflet-popup-content-wrapper {
            background: linear-gradient(60deg, yellowgreen, greenyellow);
        }

        .leaflet-popup-content-wrapper .leaflet-popup-content {
        }

        .leaflet-popup-tip-container {dots-separator fl-wrap
        }
         #contact_phone{
            cursor: pointer;
        }
        #contact_phone:hover{
            cursor: pointer;
            color: #C19D60;
        }
    </style>


    <script src="https://unpkg.com/leaflet@1.6.0/dist/leaflet.js"
            integrity="sha512-gZwIG9x3wUXg2hdXF6+rVkLF/0Vi9U8D2Ntg4Ga5I5BZpVkVxlJWbSQtXPSiUTtC0TjtGOmxa1AJPuV0CPthew=="
            crossorigin=""></script>

@endsection
    
@section('content')
<div class="content">
    <!--  section  -->
    <section class="parallax-section hero-section hidden-section" data-scrollax-parent="true"></section>
    <!--  section  end-->
    <!--  section  -->
    <section class="hidden-section">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="fl-wrap post-container">
                        <!-- post -->
                        <div class="post fl-wrap fw-post">
                            <div class="shop-header-title fl-wrap">
                                <h2 style="color: #C19D60;">{{$posts->subject}}</h2>
                                <div class="shop-header-title_opt w-100">
                                    <ul>
                                        <li>
                                            
                                                      @if($posts->price === null || $posts->price === "0")
                                                @if($posts->trending == 1)
                                                    
                                                    <span class="menu-single-preice">
                                                
                                                <strong>
                                                    مایل به معاوضه
                                                </strong>
                                                
                                                </span>
                                                    
                                                @else
                                                    <span class="menu-single-preice">قیمت :
                                                
                                                <strong>
                                                    توافقی
                                                </strong>
                                                
                                                </span>
                                                @endif
                                            @else
                                                
                                                <span class="menu-single-preice">قیمت :
                                                
                                                <strong>
                                                    {{number_format((float)$posts->price) . " تومان "}}    
                                                </strong>
                                                
                                                </span>

                                            @endif
                                            
                                            
                                            
                                        </li>
                                        
                                        </li>
                                    </ul>
                                    <span style="color: #fff; font-size: 15px; float: left;">
                                        تاریخ انتشار:
                                        {{\Morilog\Jalali\Jalalian::forge($posts->created_at)->format('Y/m/d')}}
                                    </span>
                                </div>
                            </div>
                            <div class="blog-media fl-wrap">
                                <div class="single-slider-wrap">
                                    <div class="single-slider fl-wrap">
                                        <div class="swiper-container">
                                            <div class="swiper-wrapper lightgallery">
                                                <!--<div class="swiper-slide hov_zoom">-->
                                                <!--    <img class="posts_img" src="/post_images/related_images_watermark/{{$posts->image_path}}" alt="{{$posts->subject}}">-->
                                                <!--    <a href="/post_images/related_images_watermark/{{$posts->image_path}}" class="box-media-zoom popup-image">-->
                                                <!--        <i class="fal fa-search"></i>-->
                                                <!--    </a>-->
                                                <!--</div>-->
                                                @foreach ($images as $image)

                                                <div class="swiper-slide hov_zoom">
                                                    <img class="posts_img" src="/post_images/related_images_watermark/{{$image->path}}" alt="{{$posts->subject}}">
                                                    <a href="/post_images/related_images_watermark/{{$image->path}}" class="box-media-zoom popup-image">
                                                        <i class="fal fa-search"></i>
                                                    </a>
                                                </div>

                                                @endforeach

                                            </div>
                                            <div class="ss-slider-pagination"></div>
                                            <div class="ss-slider-cont ss-slider-cont-prev"><i class="fas fa-caret-left"></i></div>
                                            <div class="ss-slider-cont ss-slider-cont-next"><i class="fas fa-caret-right"></i></div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="blog-text fl-wrap">
                                <div class="pr-tags fl-wrap">
                                    <span> نوع خودرو : </span>
                                    <ul>
                                            <li>
                                                @if($posts->is_rent == 0)
                                                    <a href="/advertises/types/{{$posts->type}}/{{$posts->type_name()}}">{{$posts->type_name()}}</a>
                                                @else
                                                    <a href="/rent/types/{{$posts->type}}/{{$posts->type_name()}}">{{$posts->type_name()}}</a>
                                                @endif
                                            </li>
                                        </ul>
                                </div>
                                <p style="white-space: pre-line;">
                                    {{$posts->description}}
                                </p>
                            </div>
                            <div class="clearfix"></div>
                            <div class="bold-separator bold-separator_dark"><span></span></div>
                            <div class="clearfix"></div>
                            @if($posts->location != null)
                            <div class="col-sm-12 mb-5">
                                <div class="map" id="maps">

                                </div>
                            </div>
                            @endif
                            <div class="shop-item-footer fl-wrap">
                               <div class="col-md-12">
                                   <div class="row" style="direction:rtl">
                                       <div class="col-md-4 mb-3">
                                              <ul class="post-counter float-md-right">
                                                <li><i class="far fa-eye"></i><span class="mr-2">{{$posts->visits()}}</span></li>
                                                <li><i class="fal fa-shopping-bag"></i><span class="mr-2">256</span></li>
                                              </ul> 
                                       </div>
                                        <div class="col-md-8 mt-2" >
                                           <p class="">18 چرخ هیچ‌گونه منفعت و مسئولیتی در قبال معامله شما ندارد</p>
                                       </div>
                                   </div>
                                 
                               </div>
                          </div>
                        </div>
                    </div>
                </div>
                <!--  sidebar  -->
                <div class="col-md-4">
                    <!-- main-sidebar -->
                    <div class="main-sidebar fixed-bar fl-wrap">

                        <div class="main-sidebar-widget fl-wrap">
                            <h3 style="color: #C19D60;">جزییات آگهی</h3>
                            <div class="category-widget">

                                <ul class="cat-item">
                                    @if($posts->is_rent == 0)
                                    <li>
                                        <h5 class="d-inline-block mb-3">محل اگهی</h5 class="d-inline-block mb-3">
                                        <p>{{$posts->State->name}} ، {{$posts->City->name}}</p>
                                    </li>
                                    <li>
                                        <h5 class="d-inline-block mb-3">نوع برند</h5 class="d-inline-block mb-3">
                                        <p>{{$posts->cbrand_id ? $posts->Cbrand->name : 'موجود نیست'}}</p>
                                    </li>
                                    <li>
                                        <h5 class="d-inline-block mb-3">نوع مدل</h5 class="d-inline-block mb-3">
                                        <p>{{$posts->cmodel_id ? $posts->Cmodel->name : 'موجود نیست'}}</p>
                                    </li>
                                    <li>
                                        <h5 class="d-inline-block mb-3">گیربکس </h5 class="d-inline-block mb-3">
                                        <p>{{$posts->gearbox_id ? $posts->Gearbox->name : 'موجود نیست'}}</p>
                                    </li>
                                    <li>
                                        <h5 class="d-inline-block mb-3">سلامت بدنه </h5 class="d-inline-block mb-3">
                                        <p>{{$posts->cbody_id ? $posts->Cbody->name : 'موجود نیست' }}</p>
                                    </li>
                                    <li>
                                        <h5 class="d-inline-block mb-3">رنگ</h5 class="d-inline-block mb-3">
                                        <p>{{$posts->color_id ? $posts->Color->name : 'موجود نیست'}}</p>
                                    </li>
                                    <li>
                                        <h5 class="d-inline-block mb-3">سال ساخت</h5 class="d-inline-block mb-3">
                                        <p>{{$posts->year_id ? $posts->Year->name : 'موجود نیست'}}</p>
                                    </li>
                                    <li>
                                        <h5 class="d-inline-block mb-3">کارکرد</h5 class="d-inline-block mb-3">
                                        <p>{{ number_format($posts->distance) }} &ensp; کیلومتر</p>
                                    </li>
                                    
                                    @else
                                    <li>
                                        <h5 class="d-inline-block mb-3">وضعیت راننده</h5 class="d-inline-block mb-3">
                                        <p>
                                        @if($posts->driver_status == '1')
                                            با
                                            راننده
                                            {{$posts->workers ? "همراه با $posts->workers کارگر " : "بدون کارگر"}}
                                        @else
                                        {{$posts->driver_status === '0'? "فرقی نمیکند" : ($posts->driver_status == '2' ? "بدون راننده" : "")}}
                                        @endif
                                        </p>
                                    </li>
                                    @endif
                                    
                                    <li>
                                        <h5 class="d-inline-block mb-3">شماره تماس</h5 class="d-inline-block mb-3">
                                        <p id="contact_phone" >{{substr_replace($posts->phone_number, '****', 4, 4)}}</p>
                                    </li>
                                    
                                    <li id="polic-alert">
                                        <div class="alert alert-info py-3 px-4 " style="direction:rtl;font-size:15px" role="alert">
                                            <span class="font-weight-bold" style="background:transparent !important;">هشدار پلیس</span>
 
                                            لطفا پیش از انجام معامله و هر نوع پرداخت وجه، از صحت خدمات ارائه شده، به صورت حضوری اطمینان حاصل نمایید  .
                                        </div>
                                     </li>
                                </ul>
                                <div class="category-widget">
                                    <div class="menu-single_rating my-3">
                                
                                        
                                                                   @if(\Illuminate\Support\Facades\Session::get('login'))
                                            <div class="markup" data-id="{{$posts->id}}">
                                                @if($data['mark'] == "")
                                                    <a class="btn success text-center">نشان کردن <i
                                                                class="fa fa-bookmark-o mx-3"></i></a>
                                                @else
                                                    <a class="btn success text-center">حذف نشان<i
                                                                class="fa fa-bookmark mx-3"></i></a>
                                                @endif

                                                {{--                                                <a class="btn success text-center">نشان کردن <i--}}
                                                {{--                                                        class="fa fa-bookmark-o mx-3"></i></a>--}}


                                            </div>
                                        @else

                                            <div class="cookmark" style="cursor: pointer" data-id="{{$posts->id}}">
                                                @if($data['mark'] == "")

                                                    <a class="btn success text-center">نشان کردن <i
                                                                class="fa fa-bookmark-o mx-3"></i></a>
                                                @else

                                                    <a class="btn success text-center">حذف نشان<i
                                                                class="fa fa-bookmark mx-3"></i></a>

                                                @endif

                                            </div>

                                        @endif
                                        
                                    </div>
                                </div>
                            </div>
                            <!-- main-sidebar-widget end-->
                        </div>
                        <!-- main-sidebar end-->
                    </div>
                    <!--  sidebar end-->
                </div>
                <div class="fl-wrap limit-box"></div>
                <div class="col-md-12">
                    <!--post-related-->
                    <div class="post-related fl-wrap">
                        <h6 class="comments-title text-right" style="color: #C19D60;">آگهی های مشابه</h6>
                        <!-- post-related -->
                        <div class=" row" style="direction: rtl">
                            @foreach ($related_posts as $post)

                            <div class="item-related col-md-4">
                                <a href="/advertises/show/{{$post['id']}}/{!! str_replace([' ' , '/'], '_', $post['subject']) !!}"><img src="/post_images/related_images_watermark/{{$post['image_path']}}" alt=""></a>
                                <h3><a href="/advertises/show/{{$post['id']}}/{!! str_replace([' ' , '/'], '_', $post['subject']) !!}">{{$post['subject']}}</a></h3>
                                            <span class="post-date post-price" style="direction: rtl">
                                                             @if($post['price'] === null || $post['price'] === "0")
                                                @if($post['trending'] == 1)
                                                 
                                                    مایل به معاوضه
                                             
                                                    
                                                @else
                                                  
                                                    توافقی
                                               
                                                @endif
                                            @else
                                                
                                             
                                                    {{number_format((float)$post['price']) . "تومان"}}    
                                             
                                            @endif
                                            
                                            
                                                </span>
                            </div>

                            {{--<img src="/post_images/related_images_watermark/{{$image->path}}"
                            class="img-rounded" alt=""
                            style="width: 100%">--}}
                            @endforeach

                        </div>
                        <a href="{{$posts->is_rent === '0' ? '/advertises/all' : '/rent/all'}}" class="btn shop-btn float-left">
                                <i class="fas fa-arrow-left align-middle mr-2 ml-0"></i>
                                آگهی های بیشتر
                            </a>
                    </div>
                    <!-- post-related  end-->
                </div>
            </div>
    </section>
    <!--  section end  -->
    <div class="brush-dec2 brush-dec_bottom"></div>
</div>
@endsection

@section('scripts')
    <script>

        $(document).ready(function () {
            
            var phone = "{{$posts->phone_number}}";

            $('#contact_phone').on('click', function () {
                $(this).text(phone);
                
                 $('#polic-alert').stop().slideDown();
           
            });

            $('.markup').on('click', function () {
                console.log("salam")
                var markup = $(this);
                var post_id = $(this).data('id');
                // console.log(proposal_id)

                var data = {"post_id": post_id, '_token': "{{csrf_token()}}"};
                $.ajax({
                    url: '/posts/ajax/mark',
                    data: data,
                    method: 'post',
                    success: function (x) {
                        console.log(x);

                        if (x === 'mark') {
                            markup.children().remove();
                            markup.append(
                                `<a class="btn success text-center">حذف نشان<i class="fa fa-bookmark mx-3"></i></a>`
                            )
                            // console.log(markup)

                        } else if (x === 'unmark') {
                            markup.children().remove();
                            markup.append(
                                `<a class="btn success text-center">نشان کردن <i class="fa fa-bookmark-o mx-3"></i></a>`
                            )
                        }
                    },
                    error: function (exception) {
                        console.log(exception);
                    }

                });
            });
            
            $('.cookmark').on('click', function () {
                console.log("set-cookie")
                var markup = $(this);
                var id = $(this).data('id');
                var base = 1; // page = customer_adv

                var data = {"id": id, "base": base, '_token': "{{csrf_token()}}"};
                $.ajax({
                    url: '/mark/cookie',
                    data: data,
                    method: 'post',
                    success: function (x) {
                        console.log(x);

                        if (x.mark) {
                            markup.children().remove();
                            markup.append(
                                `<a class="btn success text-center">حذف نشان<i
                                                            class="fa fa-bookmark mx-3"></i></a>`
                            )
                        } else {
                            markup.children().remove();
                            markup.append(
                                `<a class="btn success text-center">نشان کردن <i
                                                        class="fa fa-bookmark-o mx-3"></i></a>`
                            )
                        }


                    },
                    error: function (exception) {
                        console.log(exception);
                    }

                });
            });
            
            var d = "{{$posts->location}}"
            d = d.split(',')
            // alert(d)

            var map = L.map('maps', {
                center: [d[0],d[1]],
                zoom: 15,
                zoomControl: false
            });

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: ' 18charkh'
            }).addTo(map);


            var originIcon = L.icon({
                iconUrl: 'https://barokala.com/images/location_charkh.png',
                iconAnchor: [18, 26],
                labelAnchor: [-6, 0],
                popupAnchor: [0, -36],
                iconSize: [35, 35]
            });


            origin = L.marker([{{$posts->location}}], {icon: originIcon}).addTo(map);
       
        });

    </script>


@endsection
