<div class="themes">
    <div class="scrollbar">
        <a href="/admin/dashboard" class="themes__item active" data-sa-value="1"><img src="{{asset('/img/bg/1.jpg')}}" alt="bg1" /></a>
        <a href="/admin/dashboard" class="themes__item" data-sa-value="2"><img src="{{asset('/img/bg/2.jpg')}}" alt="bg2" /></a>
        <a href="/admin/dashboard" class="themes__item" data-sa-value="3"><img src="{{asset('/img/bg/3.jpg')}}" alt="bg3" /></a>
        <a href="/admin/dashboard" class="themes__item" data-sa-value="4"><img src="{{asset('/img/bg/4.jpg')}}" alt="bg4" /></a>
        <a href="/admin/dashboard" class="themes__item" data-sa-value="5"><img src="{{asset('/img/bg/5.jpg')}}" alt="bg5" /></a>
        <a href="/admin/dashboard" class="themes__item" data-sa-value="6"><img src="{{asset('/img/bg/6.jpg')}}" alt="bg6" /></a>
        <a href="/admin/dashboard" class="themes__item" data-sa-value="7"><img src="{{asset('/img/bg/7.jpg')}}" alt="bg7" /></a>
        <a href="/admin/dashboard" class="themes__item" data-sa-value="8"><img src="{{asset('/img/bg/8.jpg')}}" alt="bg8" /></a>
        <a href="/admin/dashboard" class="themes__item" data-sa-value="9"><img src="{{asset('/img/bg/9.jpg')}}" alt="bg9" /></a>
        <a href="/admin/dashboard" class="themes__item" data-sa-value="10"><img src="{{asset('/img/bg/10.jpg')}}" alt="bg10" /></a>
    </div>
</div>