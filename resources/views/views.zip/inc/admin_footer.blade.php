<footer class="footer d-none d-sm-block" style="margin-left: 250px">
    <p>کلیه حقوق بخش ادمین متعلق به هیراد مجد می باشد</p>

    <ul class="footer__nav">
        <a href="/admin/dashboard">صفحه اصلی </a>
        <a href="/advertises/create">ثبت آگهی </a>
        <a href="/blog/wp-admin">وبلاگ </a>
        <a href="https://18charkh.com">18 چرخ </a>
    </ul>
</footer>