@extends('layout.Main')

@section('content')
    <div class="content">
        <!--  section  -->
        <section class="parallax-section hero-section hidden-section" data-scrollax-parent="true"></section>
        <!--  section  end-->
        <!--  section  -->
        <section class="hidden-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-9">
                        <div class="fl-wrap post-container">
                            <div class="shop-header fl-wrap">
                                <h4 style="float:right"><span></span>تعداد لوکس فروشی ها :{{count($luxes)}}</h4>

                            </div>
                            <!-- gallery start -->

                            @if(count($luxes) == 0)
                                <h4 style="text-align: center;color: white">فروشگاه لوکس فروشی موجود نیست</h4>
                                <h6 style="text-align: center;color: yellowgreen">با 18 چرخ تماس بگیرید و فروشگاه خود را اینجا معرفی کنید</h6>
                            @endif

                            @foreach($luxes as $lux)
                                <div class="col-md-12 my-5 py-2"
                                     style="background: #303030;border: 1px solid rgba(255, 255, 255, 0.2);">
                                    <div class="row" style="direction: rtl">
                                        <div class="col-md-4 p-3">
                                            <div class="grid-item-holder hov_zoom" style="height: 100%">
                                                <a class="box-media-zoom "><i class="fal fa-search"></i></a>
                                                <a></a> <img style="width: 100%;height: 100%"
                                                             src="/advertise/{{$lux->main_img}}" alt="lux sell">
                                            </div>
                                        </div>
                                        <div class="col-md-8 p-3 text-right">
                                            <div class="title my-3">
                                                <h3 class="px-3  " style="color:#C19D60;">{{$lux->name}}</h3>
                                            </div>
                                            <div class="sub-title my-3">
                                                <p class="px-2"><span style="color:#C19D60;" class="mx-1 px-2"> شماره تماس :</span>{{$lux->phone_number ? $lux->phone_number: "موجود نیست"}}
                                                </p>
                                                <p class="px-2">
                                                    <span style="color:#C19D60;" class="mx-1 px-2">آدرس:</span>{{$lux->address ? $lux->address : "موجود نیست"}}</p>
                                            </div>
                                            <div class="desc-title my-3">
                                                <p class="px-2">
                                                    <span style="color:#C19D60;text-align:justify" class="mx-1 px-2">توضیحات :</span>
                                                    {{$lux->description? $lux->description: "موجود نیست"}}
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @endforeach


                        </div>
                    </div>
                    <!--  sidebar  -->
                    <div class="col-md-3">
                        <!-- main-sidebar -->
                        <div class="main-sidebar fixed-bar fl-wrap">
                            <!-- main-sidebar-widget-->
                            <div class="main-sidebar-widget fl-wrap">
                                <div class="search-widget fl-wrap">
                                    <form action="#">
                                        <button class="search-submit color-bg" id="submit_btn"><i
                                                    class="fa fa-search"></i>
                                        </button>
                                        <input name="se" id="se" type="text" class="search-inpt-item"
                                               placeholder="جستجو.."
                                               value="...جستجو" style="text-align: right"/>

                                    </form>
                                </div>
                            </div>

                            <div class="main-sidebar-widget fl-wrap">
                                <h3>فیلترها </h3>
                                <div class="recent-post-widget">
                                    <div class="shop-header_opt">
                                        <select id="state_id" data-placeholder="Persons"
                                                class="chosen-select no-search-select">
                                            <option class="list_dropdown_option">انتخاب استان</option>

                                            @foreach ($state as $s)
                                                <option class="list_dropdown_option" value="{{ $s->id }}">{{ $s->name}}</option>
                                            @endforeach

                                        </select>
                                    </div>
                                    <div class="shop-header_opt">
                                        <select id="city_id"
                                                class="chosen-select no-search-select">
                                            <option class="list_dropdown_option">انتخاب شهر</option>
                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <form action="" method="post">
                                            @csrf
                                            <input hidden class="state_id" value="" name="state">
                                            <input hidden class="city_id" value="" name="city">
                                            <button type="submit" id="btn-filter" class="btn btn-success btn-block">اعمال
                                                فیلتر
                                            </button>
                                        </form>
                                    </div>

                                </div>
                            </div>


                        </div>
                        <!-- main-sidebar end-->
                    </div>
                    <!--  sidebar end-->
                </div>
                <div class="fl-wrap limit-box"></div>
            </div>
            <div class="section-bg">
                <div class="bg" data-bg="images/bg/dec/section-bg.png"></div>
            </div>
        </section>
        <!--  section end  -->
        <div class="brush-dec2 brush-dec_bottom"></div>
    </div>
@endsection

@section('scripts')
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $(document).ready(function () {


            $('#state_id').on('change', function () {
                var stateId = $(this).val();
                $('.state_id').val(stateId);
                $("#city_id").html('<option value="">شهر مورد نظر را وارد نمایید</option>');
                if (stateId == "")
                    return;

                var pdata = {"stateId": stateId};
                $.ajax({
                    url: '/posts/getCity',
                    data: pdata,
                    method: 'post',
                    success: function (x) {
                        console.log(x);
                        var options = "";
                        var cities_item = "";
                        x.data.forEach(op => {
                            options += `<option class="list_dropdown_option" value='${op.id}'>${op.name}</option>`
                            cities_item += `<li class="option" data-value='${op.id}'>${op.name}</li>`
                        });

                        // console.log(li)

                        $('#city_id').append(`<option class="list_dropdown_option" >شهر را انتخاب کنید</option>`);
                        $('#city_id').append(options);
                        $('#city_id').closest('.shop-header_opt').find('.list').empty();
                        $('#city_id').closest('.shop-header_opt').find('.list').append(`<li class="option">شهر را انتخاب کنید</li>`);
                        $('#city_id').closest('.shop-header_opt').find('.list').append(cities_item);
                    },
                    error: function (exception) {
                        console.log(exception);
                    }

                });
            });

            $('#city_id').on('change', function () {
                var city = $(this).val();
                $('.city_id').val(city);
            })

        });

        $(window).scroll(function() {
            if ($(document).scrollTop() > 50) {
                $('.nav').addClass('affix');
                $('.navTrigger').addClass('affix_trigger');
                console.log("OK");
            } else {
                $('.nav').removeClass('affix');
                $('.navTrigger').removeClass('affix_trigger');
            }
        });
        $('.navTrigger').click(function () {
            $(this).toggleClass('active');
            console.log("Clicked menu");
            $("#mainListDiv").toggleClass("show_list");
            $("#mainListDiv").fadeIn();

        });
    </script>


@endsection
